# SOCC Route Finder — Build Prompt & Reference Spec
**Last updated:** February 2026 — reflects actual built state of the app

> This document is both the original build prompt and a living reference.
> Sections marked **⚠️ Differs from original spec** reflect lessons learned during build.

---

## Project Overview

A **public-facing cycling route finder web app** for Swavesey & Over Cycling Club (SOCC), a small
non-profit club based in Cambridgeshire, UK. Entirely free to host and operate. No backend.
No login. Single HTML file.

---

## Tech Stack

- **Database:** Google Sheets (published as CSV — no auth required)
- **Frontend:** Single-file HTML/CSS/JS, hosted on **GitHub Pages** or **Netlify** (free tier)
- **Maps:** Leaflet.js with OpenStreetMap tiles (free, no API key needed)
- **GPX rendering:** `leaflet-gpx` plugin — draws GPX tracks directly on Leaflet maps
- **Charts:** Chart.js — elevation profiles per route card
- **No backend, no server, no paid services**

### Published CSV URL format ⚠️ Differs from original spec

The original spec used the `gviz/tq` URL format. **Use the `pub` format instead** — it is more
reliable and works without any auth:

```
https://docs.google.com/spreadsheets/d/e/{2PACX_KEY}/pub?gid={GID}&single=true&output=csv
```

The `2PACX_KEY` is the **published-to-web key**, found by going to:
File → Share → Publish to web → select tab → CSV → Publish.
It is different from the Sheet ID in the address bar. It always starts with `2PACX-`.

**Current SOCC values:**
```js
SHEET_ID:  '2PACX-1vQflvwcr6Nf1NVyvv45Jt7YWF3fxZO0ecaN8JwMYU4gQeghoYR7eLmkGS7zfSqdlA8VuiIhkQ4eCAYz'
SHEET_GID: '429694098'
```

---

## Users & Roles

1. **Public / Club Members** — Browse, filter and view routes. Download GPX files. Read-only.
2. **Ride Organiser / Admin** — Manages data directly in Google Sheets. App reflects changes on next cache refresh (1 hour TTL, or manual refresh button).

No login required for either.

---

## Data Schema ⚠️ Differs from original spec

The actual sheet column names differ from the original spec. The app uses a `COLUMN_MAP` in
`CONFIG` to translate real headers to internal field names at parse time.

### Actual sheet columns → internal field names

| Actual sheet column header | Internal field name | Type | Notes |
|---|---|---|---|
| *(unnamed 3rd column)* | `type` | String | Contains `Road` or `MTB` — not Gravel as originally specced |
| `Ridable` | `rideable` | String/Boolean | See rideable logic below |
| `New routes number` | `route_number` | String | Internal numbering |
| `Route Name` | `route_name` | String | Display name |
| `Distance Miles` | `distance_miles` | Number | e.g. 27.07 |
| `Ascent (per garmin)` | `ascent_metres` | Number | Metres |
| `Garmin Connect Link` | `garmin_link` | URL | Full Garmin Connect URL |
| `Direction` | `direction` | String | Lowercase in sheet: n, nw, s/sw — normalised by app |
| `Notes` | `notes` | String | Free text — shows as ⚠️ warning banner |
| `Source` | `source` | String | e.g. "Roy's route" |
| `Busway segment` | `busway_segment` | String/Boolean | `YES`/`n`/blank — not TRUE/FALSE |
| `last ride` | `last_ridden` | String | e.g. "10 Jan", "Feb-26" |
| `debrief` | `notes_debrief` | String | Post-ride notes (parsed, not yet displayed) |
| `Speed` | `recommended_speed_mph` | Number | mph |
| `Time` | `estimated_time_raw` | Number | **Decimal hours** e.g. 1.746 — app converts to "1 h 45 min" |
| `time inc 30 minute coffee stop` | `time_with_coffee` | String | e.g. "2 h 15 min" |
| `Roy Group` | `roy_group` | Number | Internal difficulty number |
| `Comparison` | `comparison` | String | Internal flag |
| `start_lat` | `start_lat` | Number | Add this column when coordinates available |
| `start_lon` | `start_lon` | Number | Add this column when coordinates available |

### Columns from original spec not yet in the sheet
These were in the spec but don't exist in the sheet yet. When added, the COLUMN_MAP just needs
a matching entry:

| Planned column | Internal field name | Notes |
|---|---|---|
| `cafe_name` | `cafe_name` | For café filter and café marker on map |
| `cafe_hours` | `cafe_hours` | Shown in café popup |
| `cafe_maps_url` | `cafe_maps_url` | Used to extract café coordinates for map marker |
| `gpx_url` | `gpx_url` | Direct URL to GPX file — enables track overlay on maps |
| `date_added` | `date_added` | Not yet used in UI |

### Rideable logic ⚠️ Differs from original spec

Original spec: `rideable = TRUE/FALSE`. Actual sheet: column is `Ridable`, values are `YES`, `NO`,
blank, `?Check cafe`, or random text from data entry errors.

**Current behaviour:**

| Value in `Ridable` | Result |
|---|---|
| *(blank)* | ✅ Shown — blank means rideable by default |
| `YES` / `yes` / `true` | ✅ Shown |
| `NO` / `no` / `false` | ❌ Hidden |
| `?Check cafe` | ❌ Hidden |
| Any other unexpected value | ❌ Hidden (safety default) |

### Time column ⚠️ Differs from original spec

Original spec assumed `estimated_time` would be a string like `"2 h 15 min"`.
**Actual sheet stores decimal hours** (e.g. `1.746`). The app converts at parse time:

```js
// Stored in sheet as: 1.746
// Displayed as: "1 h 45 min"
const h = Math.floor(dh);
const m = Math.round((dh - h) * 60);
obj.estimated_time = m > 0 ? `${h} h ${m} min` : `${h} h`;
```

The sheet column must remain as decimal numbers — do not change the format.

### Busway column ⚠️ Differs from original spec

Original spec: `TRUE/FALSE`. Actual sheet: `YES` means uses busway, `n` or blank means it doesn't.
App normalises at parse time: `YES` → `true`, anything else → `false`.

### Direction values ⚠️ Differs from original spec

Actual sheet has lowercase direction values (`nw`, `s`, `sw`) and compound values (`s/sw`).
The app normalises via `normaliseDir()`:
- Uppercases and trims whitespace
- Splits compound values on `/` and takes the first part (`s/sw` → `S`)

### Start coordinates

No `start_lat`/`start_lon` columns exist in the sheet yet. Most routes start from Swavesey
(`52.3553, -0.0170`). When the columns are added, the app picks them up automatically via
COLUMN_MAP. Until then, the master map uses an estimated position calculated from direction
and distance from Swavesey HQ.

---

## Robustness Helpers

Every field from the sheet goes through defensive helper functions before use in the UI.
Never use raw field values directly in templates.

```js
safe(v)          // Always returns trimmed string — never crashes on null/undefined/number/boolean
safeNum(v)       // Always returns a number or 0 — never NaN
normaliseDir(d)  // Uppercase + trim + split compound (s/sw → S)
escHtml(s)       // HTML-encode for safe insertion into DOM
```

---

## UI — Implemented

### Layout
- Clean, modern, mobile-first responsive design
- Navy (`#1a2e4a`) + orange (`#e8621a`) + white + light grey
- System sans-serif font stack (no external fonts — GDPR clean)
- Desktop: filter sidebar (280px) + content area
- Mobile: filters collapse into top toggle drawer

### View modes
Two tabs above the content area:
- **📋 List** — route cards (default)
- **🗺️ Map** — master map (see below)

### Filter Panel
- Type toggle: All / Road / MTB / Gravel
- Distance slider: 0–160 miles (dual range)
- Ascent slider: 0–2500m (dual range)
- Direction checkboxes: N NE E SE S SW W NW
- Café stop only toggle
- Exclude busway toggle
- Sort: Name A–Z / Distance ↑↓ / Ascent ↑ / Last Ridden
- Live count: "Showing X of Y"
- Reset all filters button
- 🔄 Refresh route data button (clears cache, forces re-fetch)

### Route Cards
- Route name, distance/ascent/direction colour-coded badges
- Distance badge: green <25mi, amber 25–40mi, red >40mi
- Direction badge: colour-coded by compass point
- Estimated time (decimal hours auto-converted to readable string)
- Time inc. coffee stop
- Café name + hours + Google Maps link (if `cafe_name` populated)
- Last ridden date (greyed "Never ridden" if blank)
- ⚠️ amber warning banner if `notes` is populated
- 🚧 HAZARD badge if notes contain "pothole" or "roadworks"
- 🚌 busway badge if route uses busway
- Three action buttons:
  - 🗺️ View on Map — inline Leaflet map + elevation chart
  - ⬇️ Download GPX — disabled with tooltip if no `gpx_url`
  - 🔗 Garmin Connect — opens in new tab with `rel="noopener noreferrer"`
- 🔗 Share — copies URL with `#slug` hash to clipboard

### Per-card Map (when "View on Map" clicked)
- Inline Leaflet map below the card
- Stats bar: Distance | Ascent | Ride time | Time+coffee | Direction | Speed
- Start marker at `start_lat`/`start_lon` (falls back to Swavesey HQ)
- Café marker if `cafe_maps_url` contains extractable coordinates
- GPX polyline if `gpx_url` is populated (via `leaflet-gpx`)
- Elevation profile chart (Chart.js) — real data from GPX or demo profile if no GPX
- Clicking again collapses the panel
- Multiple cards can have maps open simultaneously

### Master Map View
- Single Leaflet map showing all **currently filtered** routes simultaneously
- Navy dot at Swavesey HQ (start point anchor)
- Colour-coded circle per route (same green/amber/red as distance badges)
- Circle radius scales slightly with route distance
- Solid ring = exact GPS coordinates; lighter ring = estimated position
- Tooltip on hover: route name
- Click opens popup: name, distance, ascent, time, direction, Garmin link
- "View full details →" button in popup switches to List view and scrolls + highlights the card
- Filters applied in List view update the map in real time
- If `gpx_url` present: draws the GPX track as a coloured polyline on the master map
- Map initialisation deferred with `requestAnimationFrame` to fix blank tile issue on mobile

---

## Caching

- `localStorage` cache with 1-hour TTL
- Cache key: `socc_routes_cache`
- Stores parsed + filtered route array and timestamp
- Admin override: 🔄 Refresh route data button
- Console override: `localStorage.removeItem('socc_routes_cache')` then reload
- **Note:** During development, a forced `localStorage.removeItem(CACHE_KEY)` line runs on every
  page load. Remove this line once the app is stable in production.

---

## Local Testing

**Do not open `index.html` by double-clicking.** The browser will use a `file://` URL which
blocks `fetch()` (CORS) and blocks map tile requests. Routes won't load, map tiles won't show.

```bash
# Always serve over HTTP for local testing:
python3 -m http.server 8080   # then open http://localhost:8080
```

For phone testing on the same WiFi network, use your computer's local IP:
```
http://192.168.x.x:8080
```
Or use Netlify Drop (zero build credits with `netlify.toml`).

---

## Deployment

### netlify.toml (required to prevent credit burn)
```toml
[build]
  publish = "."
  command = ""
```
With empty `command`, Netlify treats this as a plain file publish — zero build minutes used.

### GitHub Pages
Upload `index.html` to repo root → Settings → Pages → Deploy from branch → main → / (root).

---

## Security

- All sheet field values go through `escHtml()` before DOM insertion — prevents XSS
- `safe()` helper prevents type coercion attacks
- All external links: `target="_blank" rel="noopener noreferrer"` — prevents tab-napping
- No cookies, no analytics, no tracking
- No personal member data should be stored in the sheet (it is publicly readable)
- CDN libraries pinned to specific versions (Leaflet 1.9.4, Chart.js 4.4.0, leaflet-gpx 1.7.0)
- For production hardening: add SRI hashes to CDN script tags (see README for how)

---

## CONFIG Block (top of script in index.html)

```js
const CONFIG = {
  SHEET_ID:      '2PACX-1v...',    // Published-to-web key (starts with 2PACX-)
  SHEET_NAME:    'Routes',          // Tab name (informational only)
  SHEET_GID:     '429694098',       // gid= from published URL
  USE_DEMO_DATA: false,             // true = use built-in demo routes (for testing without network)
  COLUMN_MAP: {
    '':                               'type',
    'ridable':                        'rideable',
    'new routes number':              'route_number',
    'route name':                     'route_name',
    'distance miles':                 'distance_miles',
    'ascent (per garmin)':            'ascent_metres',
    'garmin connect link':            'garmin_link',
    'direction':                      'direction',
    'notes':                          'notes',
    'source':                         'source',
    'busway segment':                 'busway_segment',
    'last ride':                      'last_ridden',
    'debrief':                        'notes_debrief',
    'speed':                          'recommended_speed_mph',
    'time':                           'estimated_time_raw',
    'time inc 30 minute coffee stop': 'time_with_coffee',
    'roy group':                      'roy_group',
    'comparison':                     'comparison',
    'start_lat':                      'start_lat',
    'start_lon':                      'start_lon',
  }
};
```

**USE_DEMO_DATA: true** — uses 8 hardcoded demo routes, no network request. Use this for:
- Phone testing without a local server
- Development when the sheet is unavailable

**USE_DEMO_DATA: false** — fetches live from Google Sheets. Use this for production and for
testing the full data pipeline.

---

## Key Constants

```js
const SWAVESEY = { lat: 52.3553, lon: -0.0170 }; // Club HQ / default route start point

const DIR_BEARING = { N:0, NE:45, E:90, SE:135, S:180, SW:225, W:270, NW:315 };
// Used to estimate marker positions on master map for routes without start_lat/start_lon
```

---

## Known Issues / Future Work

| Item | Status | Notes |
|---|---|---|
| GPX files | Not yet available | Garmin Connect links work in the meantime. Add `gpx_url` column when files are hosted |
| start_lat / start_lon | Not in sheet yet | Master map uses estimated positions. Add columns to sheet; app picks up automatically |
| Roy Group not surfaced | Parsed, not shown | Could become Group 1/2/3 difficulty filter for members |
| Debrief not shown | Parsed, not shown | Could be collapsible "Ride Notes" section per card |
| Route photos | Not implemented | A `photo_url` column would improve card visual quality |
| Debug panel | Still in HTML | Remove the `id="debugPanel"` block once stable in production |
| Force cache clear | Still in script | Remove the `localStorage.removeItem(CACHE_KEY)` line at top of script once stable |
| Print view | Not implemented | Stretch goal from original spec |

---

## Design Tokens

```css
--navy:    #1a2e4a;
--orange:  #e8621a;
--white:   #ffffff;
--grey-100: #f8f9fa;
--grey-200: #e9ecef;
--grey-300: #dee2e6;
--grey-400: #adb5bd;
--grey-600: #6c757d;
```

Distance badge colours:
- Green `#22a05a` — under 25 miles
- Amber `#d97706` — 25–40 miles
- Red `#dc2626` — over 40 miles

---

## Changelog

| Version | Changes |
|---------|---------|
| 1.0 | Initial build from spec — card list, filters, inline maps, elevation charts |
| 1.1 | Switched to 2PACX- published CSV URL format |
| 1.2 | localStorage cache (1hr TTL), Refresh button |
| 1.3 | COLUMN_MAP added — maps real sheet headers to internal field names |
| 1.4 | Boolean parsing fix for YES/NO/blank; busway YES/n normalisation |
| 1.5 | safe() / safeNum() / normaliseDir() helpers — full robustness against bad data |
| 1.6 | Time column conversion (decimal hours → readable string); MTB type; sliders to 160mi/2500m |
| 1.7 | Rideable logic: blank=show, NO=hide; file:// CORS detection in debug |
| 1.8 | Master map view — filtered routes on single Leaflet map, click-to-card, GPX track overlay |

